# netpercolate
Python package for targeted percolation in social networks
